#encoding:utf-8
module Irrgarten
    class Shield
        attr_accessor :protection, :uses
        def initialize(protection, uses)
            @protection = protection
            @uses = uses
        end

        def protect
            if @uses>0
                @uses -= 1
                return @protection
            else
                return 0
            end
        end
        
        def to_s    
            return "S[#{@protection}, #{@uses}]"
        end

        def discard
            return Dice.discardElement(@uses)
        end
        
    end
end