#encoding:utf-8
module Irrgarten
    class GameState
        attr_accessor :labyrinth, :players, :monsters, :currentPlayer, :winner, :log

        def initialize(labyrinth, players, monsters, currentPlayer, winner, log)
            @labyrinth = labyrinth
            @players = players
            @monsters = monsters
            @currentPlayer = currentPlayer
            @winner = winner
            @log = log
        end

        #consultores de cada elemento privado
        #con usar solo accesor vale, pero dejo estos que ya los tengo implementados
        def getlabyrinth
            return @labyrinth
        end

        def getplayers
            return @players
        end

        def getmonsters
            return @monsters
        end

        def getcurrentPlayer
            return @currentPlayer
        end

        def getwinner
            return @winner
        end

        def getlog
            return @log
        end
    end
end
        