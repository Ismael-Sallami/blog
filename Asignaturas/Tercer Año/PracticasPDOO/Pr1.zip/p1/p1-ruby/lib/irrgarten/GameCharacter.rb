#encoding:utf-8
module Irrgarten
    class GameCharacter
        PLAYER = :player
        MONSTER = :monster
    end 
end
