#encoding:utf-8
module Irrgarten        
    class Orientation
        VERTICAL = :vertical
        HORIZONTAL = :horizontal
    end
end