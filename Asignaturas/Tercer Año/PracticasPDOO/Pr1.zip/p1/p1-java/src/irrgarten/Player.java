/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author ismael
 */
public class Player {
    private final int MAX_WEAPONS=2;
    private final int MAX_SHIELDS=3;
    private final int INITIAL_HEALTH=10;
    private final int HITS2LOSE=3;

    private String name;
    private char number;
    private float intelligence;
    private float strength;
    private float strength;
    private int health;
    private int row;
    private int col;
    private int consecutiveHits=0;

    Player ( char number, float intelligence, float strength ){
        this.number=number;
        this.intelligence=intelligence;
        this.strength=strength;
    }

    public void resurrect(){    
        throw new UnsupportedOperationException();
    }

    int getRow(){
        return row;
    }

    int getCol(){
        return col;
    }

    int getNumber(){
        return number;
    }

    public void setPos(int row, int col){
        this.row=row;
        this.col=col;
    }

    public boolean dead(){
        throw new UnsupportedOperationException();
    }

    public Directions move(Directions directions, Directions[] validMoves){
        throw new UnsupportedOperationException();
    }

    public float attack(){
        throw new UnsupportedOperationException();
    }

    public boolean defend(float receivedAttack){
        throw new UnsupportedOperationException();
    }

    public void receiveReward(){
        throw new UnsupportedOperationException();
    }
    
    public String toString(){
        throw new UnsupportedOperationException();
    }
    
    public void receiveWeapon(Weapon w){
        throw new UnsupportedOperationException();
    }
    
    public void receiveShield(Shield s){
        throw new UnsupportedOperationException();
    }
    
    public Weapon newWeapon(){
        throw new UnsupportedOperationException();
    }
    
    public Shield newShield(){
        throw new UnsupportedOperationException();
    }
    
    public float sumWeapons(){
        throw new UnsupportedOperationException();
    }
    
    public float sumShields(){
        throw new UnsupportedOperationException();
    }
    
    public float defensiveEnergy(){
        throw new UnsupportedOperationException();
    }
    
    public boolean manageHit(float receivedAttack){
        throw new UnsupportedOperationException();
    }
    
    public void resetHits(){
        throw new UnsupportedOperationException();
    }
    
    public void gotWounded(){
        throw new UnsupportedOperationException();
    }
    
    public void incConsecutiveHits(){
        throw new UnsupportedOperationException();
    }
}
