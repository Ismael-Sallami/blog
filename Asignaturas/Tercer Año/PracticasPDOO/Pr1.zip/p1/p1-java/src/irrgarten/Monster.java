/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author ismael
 */
public class Monster {
    private int HEALTH=5;
    private String name;
    private float intelligence;
    private float strength;
    private float health;
    private int row;
    private int col;
    
    Monster(String name, float intelligence, float strength, float health, int row, int col){
            this.name=name;
            this.intelligence=intelligence;
            this.strength=strength;
            this.health=health;
            this.row=row;
            this.col=col;
    }

    public boolean dead(){
        throw new UnsupportedOperationException();
    }

    public float attack(){
        throw new UnsupportedOperationException();
    }

    public void setPos(int row, int col){
        this.row=row;
        this.col=col;
    }

    @Override
    public String toString(){
        throw new UnsupportedOperationException();
    }

    public void gotWounded(){
        throw new UnsupportedOperationException();
    }

    public boolean defend(){
        throw new UnsupportedOperationException();
        //información en la siguiente práctica
    }

    

    
    
    
}
