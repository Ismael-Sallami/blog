/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author ismael
 */
class Weapon {
    private float power;
    private int uses;
    
    //constructor
    
    public Weapon (float power, int uses){
        this.power=power;
        this.uses=uses;
    }
    
    public float attack(){
        float n=0;
        if(uses>0){
            uses--;
            n=power;
        }
        return n;
    }
    
    @Override
    public String toString(){
        String cad1=Float.toString(power);
        String cad2=String.valueOf(uses);
        
        return "W["+cad1+","+cad2+"]";
    }
    
    public boolean discard(){
          return Dice.discardElement(uses);
    }
    
}