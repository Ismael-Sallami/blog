/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author ismael
 */
public class GameState {
     private String labyrinth;
     private String players;
     private String monster;
     private int currentPlayer;
     private boolean winner;
     private String log;
    
    public GameState(String labyrinth, String players, String monster, int currentPlayer, boolean winner, String log){
        this.labyrinth=labyrinth;
        this.players=players;
        this.monster=monster;
        this.currentPlayer=currentPlayer;
        this.winner=winner;
        this.log=log;
    }
    
    
    public String getlabyrinth(){
        return this.labyrinth;
    }
    
    public String getplayers(){
        return this.players; 
    }
    
    public String getmonster(){
        return this.monster; 
    }
    
    public int getcurrentPlayer(){
        return this.currentPlayer; 
    }
    
    public boolean getwinner(){
        return this.winner; 
    }
    
    public String getlog(){
        return this.log; 
    }
    
    
}
