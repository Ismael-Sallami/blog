/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

import java.util.Random;

/**
 *
 * @author ismael
 */
public class Dice {
        private static  final int MAX_USES = 5; // número máximo de usos de armas y escudos
        private static  final float MAX_INTELLIGENCE = 10.0f; // valor máximo para la inteligencia de jugadores y monstruos
        private static  final float MAX_STRENGTH = 10.0f; // valor máximo para la fuerza de jugadores y monstruos
        private static  final float RESURRECT_PROB = 0.3f; // probabilidad de que un jugador sea resucitado en cada turno
        private static  final int WEAPONS_REWARD = 2; // número máximo de armas recibidas al ganar un combate
        private static  final int SHIELDS_REWARD = 3; // número máximo de escudos recibidos al ganar un combate
        private static  final int HEALTH_REWARD = 5; // número máximo de unidades de salud recibidas al ganar un combate
        private static  final int MAX_ATTACK = 3; // máxima potencia de las armas
        private static  final int MAX_SHIELD = 2; // máxima potencia de los escudos
        
        private static final Random generator=new Random();
        
        static public int randomPos(int max){
            return generator.nextInt(max);
        }
        
        static public int whoStarts(int nplayers){
            return generator.nextInt(nplayers);
        }
        
        static float randomIntelligence(){
            return generator.nextFloat(MAX_INTELLIGENCE);
        }
        
        float randomStrength(){
            return generator.nextFloat(MAX_STRENGTH);
        }
        
        static boolean resurrectPlayer(){
            return generator.nextFloat(1)<RESURRECT_PROB;
        }
        
        static public int weaponsReward(){
            //indica la cantidad de armas que recibirá el jugador por ganar el combate.
            return generator.nextInt(WEAPONS_REWARD)+1;
        }
        
        static public int shieldsReward(){
             return generator.nextInt(SHIELDS_REWARD)+1;
        }
        
        static public int healthReward(){
            return generator.nextInt(HEALTH_REWARD)+1;
        }
        
        static public float weaponPower(){
            return generator.nextInt(MAX_ATTACK);
        }
   
        static public float shieldPower(){
            return generator.nextInt(MAX_SHIELD);
        }
        
        static public int usesLeft(){
             return generator.nextInt(MAX_USES)+1;
        
        }
        
        static public float intensity(float competence){
            return generator.nextFloat(competence);
        }
        
        static public boolean discardElement(int usesLeft){            
            return generator.nextFloat(1) < (((float)MAX_USES-usesLeft)/MAX_USES); 
        }
   }