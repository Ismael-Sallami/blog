/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author ismael
 */
public class Shield {
       private float protection;
       private int uses;
       
       public Shield(float protection, int uses){
           this.protection=protection;
           this.uses=uses;
       }
       
       public float protect(){
        float n=0;
        if(uses>0){
            uses--;
            n=protection;
        }
        return n;
        }
       
       @Override
        public String toString(){
            String cad1=Float.toString(protection);
            String cad2=String.valueOf(uses);

            return "S["+cad1+","+cad2+"]";
        }
        
        public boolean discard(){
          return Dice.discardElement(uses);
    }
   }